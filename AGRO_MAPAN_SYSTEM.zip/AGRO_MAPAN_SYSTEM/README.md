# AGRO_MAPAN_SYSTEM
File ZIP siap pakai berisi template faktur, laporan stok, dan nota pembelian untuk:
**PT. AGRO MAPAN SENTOSA**

Alamat: Jln Raya Rawajitu Selatan
Email: agromapansentosa@gmail.com

Folder:
- Faktur_Penjualan: template HTML/CSS, contoh data Excel
- Laporan_Stok: template Excel & panduan
- Nota_Pembelian: template HTML/CSS & Excel
- index.html: menu sederhana untuk membuka file
- logo_agro_mapan.png: logo sederhana (teks)

Cara pakai singkat:
1. Ekstrak ZIP ke komputer Anda.
2. Buka `index.html` di browser untuk melihat menu.
3. Untuk mengubah data massal, edit file Excel di masing-masing folder.
